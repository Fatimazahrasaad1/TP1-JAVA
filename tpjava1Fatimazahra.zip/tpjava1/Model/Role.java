package Model;

public enum Role{
    ADMIN,
    EMPLOYE 
}