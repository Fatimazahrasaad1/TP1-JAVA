/**
 * 
 */
/**
 * 
 */
module tp1_avancee {
	requires java.sql;
	requires java.desktop;
}